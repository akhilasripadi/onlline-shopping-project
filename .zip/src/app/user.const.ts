export const userName = [{
    username: "srinivas",
    password: "123"
}, {
    username: "akhila",
    password: "12345",
},
{
    username: "siri",
    password: "1122",
},
{
    username: "devansh",
    password: "143",
},
{
    username: "sampath",
    password: "3344",
},
{
    username: "upendrachary",
    password: "5566",
},
{
    username: "ammu",
    password: "777",
},
]